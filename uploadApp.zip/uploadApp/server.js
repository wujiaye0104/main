// 上传文件
var express = require('express');
var app = express();
var fs = require('fs');

var bodyParser = require('body-parser');//用于处理JSON，url等编码数据
var multer = require('multer');//用于处理mutipart/form-data表单数据
var uploads = multer({dest: './public/uploads/'});//告诉multer上传数据保存在哪

app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended:false}));
// app.use(multer({dest:'/tmp/'}).array('image'));

app.get('/index.html',function (req, res) {
    res.sendFile(__dirname+'/'+'index.html');//传送指定路径文件(绝对路径)
});

app.post('/file_upload',uploads.array('image'),function (req, res) {
    // var des_file = __dirname+'/'+req.files[0].originalname;
    var des_file = './public/images/'+req.files[0].originalname;
    fs.readFile(req.files[0].path,function (err, data) {
        fs.writeFile(des_file,data,function (err) {
            if(err){
                console.log(err);
            }else {
                response = {
                    message:'Successfully!',
                    filename:req.files[0].originalname
                };
                // //获取临时路径
                // var tmp_path = req.files[0].originalname;//指定文件上传之后的存储目录
                // var target_path = './public/images/'+ req.files[0].originalname;//移动文件到你想上传的目录
                // fs.rename(tmp_path,target_path,function(err){
                //     if(err){//抛出异常
                //         console.log(err)
                //     }else{
                //         console.log('移动成功')
                //     }
                // });
            }
            // console.log(response);
            // console.log(JSON.stringify((response)));
            // res.end(JSON.stringify(response));
            res.json(response);
        })
    })
})

var server = app.listen(8081,function () {
    var port = server.address().port;
    console.log('ok');
    console.log('http://localhost:'+port+'/index.html');
})
