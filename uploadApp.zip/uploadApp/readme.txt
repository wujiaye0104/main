运行：
node server.js


文件下载路径：
public/images
文件缓存路径：
public/uploads
HTML：
index.html
JS:
server.js
