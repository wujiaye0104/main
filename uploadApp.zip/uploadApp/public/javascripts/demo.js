var express = require('express');
var app = express();
var fs = require('fs');

var bodyParser = require('body-parser');
var multer = require('multer');
var uploads = multer({dest: './public/uploads/'});

app.use(express.static('public'));
app.use(bodyParser.urlencoded({extended: false}));

app.get('/index.html',function (req, res) {
    res.sendFile(__dirname+'/index.html');
});

app.post('/file_upload',uploads.array('image'),function (req, res) {
    var des_file = './public/images/'+req.files[0].originalname;
    fs.readFile(req.files[0].path,function (err,data) {
        if(err){
            console.log(err+'1');
        }else{
            fs.writeFile(des_file,data,function (err) {
                if (err) {
                 console.log(err+'2');
                }else {
                    response = {
                        message:'OK',
                        filename: req.files[0].originalname
                    }
                }
                console.log(response);
                res.json(response);
            })
        }
    })
});

var server = app.listen(8081,function () {
    var port = server.address().port;
    console.log('ok');
    console.log('http://localhost:'+port+'/index.html');
})
